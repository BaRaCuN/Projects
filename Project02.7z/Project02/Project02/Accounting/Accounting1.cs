﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project02.Accounting
{
    class Accounting1: INotifyPropertyChanged
    {
        private string _object1;
        public string Object1
        {
            get { return _object1; }
            set 
            {
                if (_object1 == value)
                    return;
                _object1 = value;
                OnPropertyChanged("Object1");                
            }
        }
        private string _object2;
        public string Object2
        {
            get { return _object2; }
            set
            {
                if (_object2 == value)
                    return;
                _object2 = value;
                OnPropertyChanged("Object2");
            }
        }
        private string _object3;
        public string Object3
        {
            get { return _object3; }
            set
            {
                if (_object3 == value)
                    return;
                _object3 = value;
                OnPropertyChanged("Object3");
            }
        }
        private string _object4;
        public string Object4
        {
            get { return _object4; }
            set
            {
                if (_object4 == value)
                    return;
                _object4 = value;
                OnPropertyChanged("Object4");
            }
        }
        private string _object5;
        public string Object5
        {
            get { return _object5; }
            set
            {
                if (_object5 == value)
                    return;
                _object5 = value;
                OnPropertyChanged("Object5");
            }
        }
        private string _object6;
        public string Object6
        {
            get { return _object6; }
            set
            {
                if (_object6 == value)
                    return;
                _object6 = value;
                OnPropertyChanged("Object6");
            }
        }
        private string _student;
        public string Student
        {
            get { return _student; }
            set
            {
                if (_student == value)
                    return;
                _student = value;
                OnPropertyChanged("Student");
            }
        }
        private string _courses;
        public string Courses
        {
            get { return _courses; }
            set
            {
                if (_courses == value)
                    return;
                _courses = value;
                OnPropertyChanged("Courses");
            }

        }

        public event PropertyChangedEventHandler PropertyChanged;
       
        protected virtual void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
