﻿using Newtonsoft.Json;
using Project02.Accounting;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project02.Services
{
    class FileIOServices
    {
        private readonly string PATH;
        
        public FileIOServices(string path)
        {
            PATH = path;
        }
        public BindingList<Accounting1> LoadData()
        {
            var fileExists = File.Exists(PATH);
            if (!fileExists)
            {
                File.CreateText(PATH).Dispose();
                return new BindingList<Accounting1>();
            }
            using (var reader = File.OpenText(PATH))
            {
                var fileText = reader.ReadToEnd();
                return JsonConvert.DeserializeObject<BindingList<Accounting1>>(fileText);
            }
        }
        public void SaveData(BindingList<Accounting1> student)
        {
            using (StreamWriter writer = File.CreateText(PATH))
            {
                string output = JsonConvert.SerializeObject(student);
                writer.Write(output);
            }
        }
    }
}
