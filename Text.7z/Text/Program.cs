﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace Text
{
    class Program
    {
        static void Main(string[] args)
        {
            var rowsInLine = 60;
            var dict = new Dictionary<string, List<int>>();
            string[] line;
            int countOfRows = 0;
            using (var sr = new StreamReader(@"C:\Users\mvideo\OneDrive\Desktop\1.txt"))
            {
                while (!sr.EndOfStream)
                {
                    line = sr.ReadLine().ToLower().Split(",.? !\'()\"".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    countOfRows++;
                    foreach (var word in line)
                    {
                        if (!dict.ContainsKey(word)) dict.Add(word, new List<int>()
                    {
                        countOfRows / rowsInLine + 1 });
                        else dict[word].Add(countOfRows / rowsInLine + 1);
                    }
                }
                var result = dict.OrderBy(x => x.Key).GroupBy(x => x.Key[0]).OrderBy(x => x.Key);
                foreach (var group in result)
                {
                    Console.WriteLine(group.Key.ToString().ToUpper());
                    foreach (var item in group)
                    {
                        Console.WriteLine(item.Key.PadRight(20, '.') + " " + item.Value.Count + " " + string.Join(" ", item.Value.Distinct()));
                    }
                }
            }
        }
    }
}

