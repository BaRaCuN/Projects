﻿using System;

namespace NumericalIntegration
{
    internal class Program
    {
        private static void Main()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("1. The Newton-Cotes formula. \n2. Trapezoid formula.\n3.Simpsons formula.\n4. Gauss formula. \n5. Chebyshev's formula.");
                int sw = int.Parse(Console.ReadLine());
                switch (sw)
                {
                    case 1:
                        NewtonCotes();
                        break;
                    case 2:
                        Trapezoid();
                        break;
                    case 3:
                        Simpson();
                        break;
                    case 4:
                        Gauss();
                        break;
                    case 5:
                        Chebyshev();
                        break;
                }
            }
        }
        static void NewtonCotes()
        {
            Console.Clear();
            Console.WriteLine("Enter the value a: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the value b: ");
            int b = int.Parse(Console.ReadLine());
            int c = (a + b) / 2;
            Console.WriteLine(c);
            Console.ReadKey();
        }
        static void Trapezoid()
        {

            Console.Clear();
            Console.WriteLine("Enter the value a: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the value b: ");
            int b = int.Parse(Console.ReadLine());
            int c = ((b - a) / 2) * (a + b);
            Console.WriteLine(c);
            Console.ReadKey();
        }

        static void Simpson()
        {
            Console.Clear();
            Console.WriteLine("Enter the value a: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the value b: ");
            int b = int.Parse(Console.ReadLine());
            int c = ((b - a) / 6) * (a + 4 * ((a + b) / 2) + b);
            Console.WriteLine(c);
            Console.ReadKey();
        }


        static void Gauss()
        {

            Console.Clear();
            Console.WriteLine("Enter the full charge contained in volume V: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the electrical constant: ");
            int b = int.Parse(Console.ReadLine());
            int c = a / b;
            Console.WriteLine(c);
            Console.ReadKey();
        }
        static void Chebyshev()
        {

            Console.Clear();
            Console.WriteLine("Enter the value a: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the value b: ");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the value c: ");
            int c = int.Parse(Console.ReadLine());
            int d = 3 * a - 2 * b - c;
            Console.WriteLine(d);
            Console.ReadKey();
        }
    }
}

