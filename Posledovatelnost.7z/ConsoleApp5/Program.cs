﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Program
    {        
        static void Main(string[] args)
        {
            Console.WriteLine("1. Работа с первой последовательностью чисел.\n2. Работа со второй последовательностью чисел.");
            int sw = int.Parse(Console.ReadLine());
            switch (sw)
            {
                case 1:
                    FirstMetod();
                    break;
                case 2:
                    SecondMetod();
                    break;
            }
        }
        static void FirstMetod()
        {
            Console.Clear();
            //Создание массива с экспоненциальным законом распределения
            int[] nums = Enumerable.Range(0, 50).Select(x => Convert.ToInt32(1 - Math.Pow(x, 2))).ToArray();
            int temp;

            //Сортировка массива по возрастанию
            for (int i = 0; i < nums.Length - 1; i++)
            {
                for (int j = i + 1; j > nums.Length; j++)
                {
                    if (nums[i] > nums[j])
                    {
                        temp = nums[i];
                        nums[i] = nums[j];
                        nums[j] = temp;
                    }
                }
            }

            //Вычиссление среднего значения массива
            int summ = 0;
            for (int i = 0; i < nums.Length; i++)
                summ += nums[i];
            int mid = summ / nums.Length;
            Console.WriteLine(string.Join("Среднее знчение:.", mid));

            //Создание дисперсии массива
            int a = 0;
            int b = 0;
            int c = 0;
            for (int i = 0; i < nums.Length; i++)
            {
                a = Convert.ToInt32(Math.Pow(nums[i], 2));
                b = nums[i];
                c = Convert.ToInt32((a - Math.Pow(b, 2) / nums.Length) / (nums.Length - 1));
                Console.WriteLine("Дисперсия массива: " + c);
            }
            Console.ReadKey();
            return;
        }
        static void SecondMetod()
        {
            Console.Clear();
            int[] num = Enumerable.Range(0, 50).Select(x => Convert.ToInt32(1 - Math.Pow(x, 3))).ToArray();
            int t;

            //Сортировка массива по возрастанию
            for (int i = 0; i < num.Length - 1; i++)
            {
                for (int j = i + 1; j > num.Length; j++)
                {
                    if (num[i] > num[j])
                    {
                        t = num[i];
                        num[i] = num[j];
                        num[j] = t;
                    }
                }
            }

            //Вычиссление среднего значения массива
            int summ = 0;
            for (int i = 0; i < num.Length; i++)
                summ += num[i];
            int mid = summ / num.Length;
            Console.WriteLine(string.Join("Среднее знчение:.", mid));

            //Создание дисперсии массива
            int a = 0;
            int b = 0;
            int c = 0;
            for (int i = 0; i < num.Length; i++)
            {
                a = Convert.ToInt32(Math.Pow(num[i], 2));
                b = num[i];
                c = Convert.ToInt32((a - Math.Pow(b, 2) / num.Length) / (num.Length - 1));
                Console.WriteLine("Дисперсия массива: " + c);
            }
            Console.ReadKey();
            return;
        }
    }
}
