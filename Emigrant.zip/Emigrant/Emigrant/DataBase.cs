﻿using System.Data.SqlClient;

namespace Product
{
    internal class DataBase
    {
        SqlConnection sqlConnection = new SqlConnection(@"Data Source = LAPTOP-G4RIF4FA\SQLEXPRESS; Initial Catalog=products; Integrated Secutity=True");
        //Data Source = LAPTOP-G4RIF4FA\SQLEXPRESS - название сервера в mssql
        //Initial Catalog=products - название таблицы
        //Integrated Secutity=True - надо

        public void openConnectoin() //если открыто соединение, то закрывает sql соединение
        {
            if(sqlConnection.State == System.Data.ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
        }
        public void closeConnectoin() //если закрыто соединение, то открывает sql соединение
        {
            if(sqlConnection.State == System.Data.ConnectionState.Open)
            {
                sqlConnection.Close();
            }
        }
        public SqlConnection GetConnection() //возвращает значение соединение 
        {
            return sqlConnection;
        }
    }
}
