﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArmstrongNumber
{
    internal class Program
    {
        static bool IsArmstrong(int _val)
        {
            string valueInString = _val.ToString(); //получаем строковое представление числа

            var digits = valueInString.Select(x => int.Parse(x.ToString())); //последовательность цифр в числе - каждый символ строки, приведенный к int

            int n = digits.Count();//количество цифр

            return _val == digits.Select(x => Math.Pow(x, n)).Sum(); //каждую цифру возводим в степень - последовательность суммируем,  проверяем на равность исходному числу и возвращаем да\нет

        }

        static void Main(string[] args)
        {
            Console.Write("Введите интервал b: ");

            int M = int.Parse(Console.ReadLine());

            var values = Enumerable.Range(1, M).Where(x => IsArmstrong(x)); //- генерация последовательности чисел от 1 до М, и выборка только чисел армстронга


            Console.WriteLine("Вычисление...");
            foreach (var value in values) Console.WriteLine(value); //вот те цикл
            Console.WriteLine("Вычисление завершено!");
            Console.ReadKey();
        }
    }
}
