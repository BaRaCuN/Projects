﻿using System;
using System.Linq;

namespace ArmstromgNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите интервал b:");
            int M = int.Parse(Console.ReadLine());

            var values = Enumerable.Range(1, M).Where(x => IsArmstong(x));

            Console.WriteLine("Вычисление...");
            foreach(var value in values)
            {
                Console.WriteLine("Вычисление завершено!");
            }    
        }
        static bool IsArmstong(int _val)
        {
            string valueInString = _val.ToString();
            var digits = valueInString.Select(x => int.Parse(x.ToString()));
            int n = digits.Count();
            return _val == digits.Select(x=> Math.Pow(x, n)).Sum();
        }
    }
}
